#!/bin/sh
APP="CryptoCrack"
APP_VERSION="0.6.0"
SELF="$(cd "$(dirname "$0")" && pwd)/$(basename "$0")"

UNATTENDED=0
SCOPE=""
PREFIX=""
DATADIR=""
DO_UNINSTALL=0
FORCE_TEXT=0
for a in "$@"; do
    case "$a" in
        -y|--yes|--unattended) UNATTENDED=1 ;;
        --user) SCOPE=user ;;
        --system) SCOPE=system ;;
        --prefix=*) PREFIX="${a#*=}" ;;
        --data=*) DATADIR="${a#*=}" ;;
        --text) FORCE_TEXT=1 ;;
        --uninstall) DO_UNINSTALL=1 ;;
        -h|--help)
            cat <<H
$APP $APP_VERSION installer

  sh $(basename "$0")              start the install wizard
  --yes                            no questions, use the recommended choices
  --user | --system                install for this user only / for all users
  --prefix=DIR                     program folder
  --data=DIR                       data folder (sample ciphers, saved sessions)
  --text                           text wizard even when a desktop is running
  --uninstall                      remove CryptoCrack
H
            exit 0 ;;
    esac
done

OS="$(uname -s)"
ARCH="$(uname -m)"
DISTRO_NAME="Linux"; PKG=""
if [ -r /etc/os-release ]; then
    . /etc/os-release
    DISTRO_NAME="${PRETTY_NAME:-$NAME}"
fi
command -v apt-get >/dev/null 2>&1 && PKG=apt
[ -z "$PKG" ] && command -v dnf >/dev/null 2>&1 && PKG=dnf
[ -z "$PKG" ] && command -v yum >/dev/null 2>&1 && PKG=yum
[ -z "$PKG" ] && command -v pacman >/dev/null 2>&1 && PKG=pacman
[ -z "$PKG" ] && command -v zypper >/dev/null 2>&1 && PKG=zypper

IS_ROOT=0; [ "$(id -u)" = "0" ] && IS_ROOT=1
HAS_SUDO=0; command -v sudo >/dev/null 2>&1 && HAS_SUDO=1
HAS_PKEXEC=0; command -v pkexec >/dev/null 2>&1 && HAS_PKEXEC=1
GLIBC="$(ldd --version 2>/dev/null | head -n1 | grep -o '[0-9]\+\.[0-9]\+$')"
DESKTOP=0; { [ -n "$DISPLAY" ] || [ -n "$WAYLAND_DISPLAY" ]; } && DESKTOP=1
LEGACY_DEB=0; dpkg -s cryptocrack 2>/dev/null | grep -q '^Status: install ok installed' && LEGACY_DEB=1
LEGACY_USER=0; [ -d "$HOME/.local/share/cryptocrack/releases" ] && LEGACY_USER=1

UI=plain
if [ $FORCE_TEXT -eq 0 ] && [ $DESKTOP -eq 1 ]; then
    if command -v zenity >/dev/null 2>&1; then UI=zenity
    elif command -v kdialog >/dev/null 2>&1; then UI=kdialog
    fi
fi
if [ "$UI" = plain ] && [ -t 0 ] && [ -t 1 ]; then
    if command -v whiptail >/dev/null 2>&1; then UI=whiptail
    elif command -v dialog >/dev/null 2>&1; then UI=dialog
    fi
fi
[ $UNATTENDED -eq 1 ] && UI=plain
TITLE="$APP $APP_VERSION Setup"

info() {
    set -- "$(printf '%b' "$1")"
    case "$UI" in
        zenity) zenity --info --title="$TITLE" --width=520 --text="$1" 2>/dev/null ;;
        kdialog) kdialog --title "$TITLE" --msgbox "$1" ;;
        whiptail|dialog) $UI --title "$TITLE" --msgbox "$1" 20 74 ;;
        *) printf '\n%s\n' "$1"; [ $UNATTENDED -eq 0 ] && [ -t 0 ] && { printf 'Press Enter to continue...'; read _r; } ;;
    esac
}
fail() {
    set -- "$(printf '%b' "$1")"
    case "$UI" in
        zenity) zenity --error --title="$TITLE" --width=480 --text="$1" 2>/dev/null ;;
        kdialog) kdialog --title "$TITLE" --error "$1" ;;
        whiptail|dialog) $UI --title "$TITLE" --msgbox "ERROR\n\n$1" 16 74 ;;
        *) printf '\nERROR: %s\n' "$1" >&2 ;;
    esac
    exit 1
}
yesno() {
    _q="$(printf '%b' "$1")"; _def="${2:-0}"
    [ $UNATTENDED -eq 1 ] && return "$_def"
    case "$UI" in
        zenity) zenity --question --title="$TITLE" --width=480 --text="$_q" 2>/dev/null ;;
        kdialog) kdialog --title "$TITLE" --yesno "$_q" ;;
        whiptail|dialog) $UI --title "$TITLE" --yesno "$_q" 16 74 ;;
        *)
            if [ "$_def" = 0 ]; then printf '\n%s [Y/n] ' "$_q"; else printf '\n%s [y/N] ' "$_q"; fi
            read r
            case "$r" in
                y|Y|yes|Yes) return 0 ;;
                n|N|no|No) return 1 ;;
                *) return "$_def" ;;
            esac ;;
    esac
}
choose() {
    q="$(printf '%b' "$1")"; def="$2"; shift 2
    [ $UNATTENDED -eq 1 ] && { echo "$def"; return; }
    case "$UI" in
        zenity)
            r=$( (
                while [ $# -gt 0 ]; do
                    if [ "$1" = "$def" ]; then echo TRUE; else echo FALSE; fi
                    echo "$1"; echo "$2"; shift 2
                done
            ) | zenity --list --radiolist --title="$TITLE" --width=620 --height=320 --text="$q" --column=" " --column=id --column=Option --hide-column=2 --print-column=2 2>/dev/null) || exit 1
            echo "$r" ;;
        kdialog)
            r=$(eval "kdialog --title \"\$TITLE\" --radiolist \"\$q\" $(while [ $# -gt 0 ]; do if [ "$1" = "$def" ]; then s=on; else s=off; fi; printf '"%s" "%s" %s ' "$1" "$2" "$s"; shift 2; done)") || exit 1
            echo "$r" ;;
        whiptail|dialog)
            n=$(($# / 2))
            r=$(eval "$UI --title \"\$TITLE\" --radiolist \"\$q\" 18 76 $n $(while [ $# -gt 0 ]; do if [ "$1" = "$def" ]; then s=ON; else s=OFF; fi; printf '"%s" "%s" %s ' "$1" "$2" "$s"; shift 2; done)" 3>&1 1>&2 2>&3) || exit 1
            echo "$r" ;;
        *)
            printf '\n%s\n' "$q" >&2; i=1; tags=""
            while [ $# -gt 0 ]; do
                mark=" "; [ "$1" = "$def" ] && mark="*"
                printf '  %s %d) %s\n' "$mark" "$i" "$2" >&2
                tags="$tags $1"; shift 2; i=$((i + 1))
            done
            printf 'Choice [default *]: ' >&2; read r
            case "$r" in
                ''|*[!0-9]*) echo "$def" ;;
                *) set -- $tags; eval "echo \${$r:-$def}" ;;
            esac ;;
    esac
}
askdir() {
    _q="$(printf '%b' "$1")"; _d="$2"
    [ $UNATTENDED -eq 1 ] && { echo "$_d"; return; }
    case "$UI" in
        zenity) r=$(zenity --entry --title="$TITLE" --width=560 --text="$_q" --entry-text="$_d" 2>/dev/null) || exit 1; echo "${r:-$_d}" ;;
        kdialog) r=$(kdialog --title "$TITLE" --inputbox "$_q" "$_d") || exit 1; echo "${r:-$_d}" ;;
        whiptail|dialog) r=$($UI --title "$TITLE" --inputbox "$_q" 12 76 "$_d" 3>&1 1>&2 2>&3) || exit 1; echo "${r:-$_d}" ;;
        *) printf '\n%s\n[%s]: ' "$_q" "$_d" >&2; read r; echo "${r:-$_d}" ;;
    esac
}
absdir() {
    case "$1" in
        "~") echo "$HOME" ;;
        "~/"*) echo "$HOME/${1#\~/}" ;;
        /*) echo "$1" ;;
        *) echo "$HOME/$1" ;;
    esac
}
progress() {
    _t="$(printf '%b' "$1")"
    case "$UI" in
        zenity) zenity --progress --title="$TITLE" --width=480 --auto-close --no-cancel --text="$_t" 2>/dev/null ;;
        whiptail|dialog) grep --line-buffered -v '^#' | $UI --title "$TITLE" --gauge "$_t" 8 70 0 ;;
        *) while read line; do case "$line" in \#*) echo "  ${line#\#}" ;; esac; done ;;
    esac
}
sq() { printf "'%s'" "$(printf '%s' "$1" | sed "s/'/'\\\\''/g")"; }

as_root() {
    if [ $IS_ROOT -eq 1 ]; then sh -c "$1"
    elif [ "$UI" = zenity ] || [ "$UI" = kdialog ]; then
        if [ $HAS_PKEXEC -eq 1 ]; then pkexec sh -c "$1"; else sudo sh -c "$1"; fi
    else sudo sh -c "$1"; fi
}

TAB="$(printf '\t')"
MANIFEST="${XDG_CONFIG_HOME:-$HOME/.config}/cryptocrack/install.txt"
uninstall() {
    entries=""
    [ -f "$MANIFEST" ] && entries=$(cat "$MANIFEST")
    for d in "$HOME/.local/share/cryptocrack" /opt/cryptocrack; do
        if [ -f "$d/run.sh" ] && ! printf '%s\n' "$entries" | cut -f2 | grep -qx "$d"; then
            if [ "$d" = /opt/cryptocrack ]; then
                entries="$entries
system${TAB}/opt/cryptocrack${TAB}/usr/local/bin/cryptocrack${TAB}/usr/share/applications${TAB}/usr/share/icons/hicolor/256x256/apps"
            else
                entries="$entries
user${TAB}$d${TAB}$HOME/.local/bin/cryptocrack${TAB}$HOME/.local/share/applications${TAB}$HOME/.local/share/icons/hicolor/256x256/apps"
            fi
        fi
    done
    entries=$(printf '%s\n' "$entries" | grep -v '^$' | sort -u)
    [ -z "$entries" ] && fail "$APP is not installed."
    list=$(printf '%s\n' "$entries" | cut -f2 | sed 's/^/  /')
    yesno "Remove $APP from:\n$list\n\nYour data folder (sample ciphers, saved sessions) is kept." || exit 0
    printf '%s\n' "$entries" | while IFS="$TAB" read sc pre bl ad ic; do
        [ -n "$pre" ] || continue
        cmd="rm -rf $(sq "$pre"); rm -f $(sq "$bl") $(sq "$(dirname "$bl")/cryptocrack-cli") $(sq "$ad/cryptocrack.desktop") $(sq "$ic/cryptocrack.png")"
        if [ "$sc" = system ]; then
            [ $LEGACY_DEB -eq 1 ] && cmd="dpkg -r cryptocrack >/dev/null 2>&1 || true; $cmd"
            as_root "$cmd"
        else sh -c "$cmd"; fi
    done
    rm -f "$HOME/Desktop/cryptocrack.desktop" "$MANIFEST" 2>/dev/null
    info "$APP was removed."
    exit 0
}
[ $DO_UNINSTALL -eq 1 ] && uninstall

[ "$OS" = Linux ] || fail "This installer is for Linux. Detected: $OS $ARCH."
case "$ARCH" in amd64) ARCH=x86_64 ;; arm64) ARCH=aarch64 ;; esac

SETUPBIN="${CC_SETUP_EXE:-$(dirname "$SELF")/CryptoCrack Setup}"
if [ -z "$CC_PAYLOAD_DIR" ]; then
    [ -f "$SETUPBIN" ] || fail "\"CryptoCrack Setup\" must be in the same folder as this script."
    CC_PAYLOAD_DIR=$(mktemp -d)
    CLEAN_PAYLOAD=1
    magic=$(tail -c 8 "$SETUPBIN")
    [ "$magic" = CCSETUP1 ] || fail "The installer data is damaged. Download it again."
    plen=$(tail -c 16 "$SETUPBIN" | head -c 8 | od -An -t u8 | tr -d ' \n')
    command -v xz >/dev/null 2>&1 || fail "The xz tool is needed to unpack the installer data (package xz-utils or xz). Or run \"CryptoCrack Setup --text\" instead."
    tail -c $((plen + 16)) "$SETUPBIN" | head -c "$plen" | xz -dc | tar xf - -C "$CC_PAYLOAD_DIR" || fail "Could not unpack the installer data."
fi
PREBUILT=0
[ "$ARCH" = x86_64 ] && [ -x "$CC_PAYLOAD_DIR/runtime/bin/cryptocrack-desktop" ] && PREBUILT=1

info "Welcome to the $APP $APP_VERSION setup wizard.\n\nCryptoCrack is a native Rust port of the CryptoCrack 4.0 cipher solver: decoders and key searches for more than 80 classical cipher types, identification, statistics and word tools.\n\nThis wizard checks your machine, picks the right install method and sets everything up."

if [ $PREBUILT -eq 1 ]; then METHOD="Ready-made program for $ARCH with its own GTK runtime"; else METHOD="Build from the bundled source code (no ready-made program for $ARCH)"; fi
[ -n "$GLIBC" ] && GL="glibc $GLIBC" || GL="glibc unknown"
OLD=""; { [ $LEGACY_DEB -eq 1 ] || [ $LEGACY_USER -eq 1 ]; } && OLD="\n\nAn older CryptoCrack 0.5 installation was found and will be replaced."
SUM="Your machine:\n\n  System:        $DISTRO_NAME\n  Processor:     $ARCH\n  C library:     $GL\n  Package tool:  ${PKG:-none found}\n  Desktop:       $( [ $DESKTOP -eq 1 ] && echo yes || echo no )\n  Administrator: $( [ $IS_ROOT -eq 1 ] && echo yes || { [ $HAS_SUDO -eq 1 ] && echo 'via sudo' || echo no; } )\n\nInstall method:\n  $METHOD$OLD"
yesno "$SUM\n\nContinue?" || exit 0

if [ -z "$SCOPE" ]; then
    if [ $IS_ROOT -eq 1 ]; then def=system; else def=user; fi
    if [ $IS_ROOT -eq 1 ] || [ $HAS_SUDO -eq 1 ] || [ $HAS_PKEXEC -eq 1 ]; then
        SCOPE=$(choose "Who should be able to use $APP?" "$def" \
            user "Just me (no administrator password, installs to ~/.local)" \
            system "Everyone on this computer (needs administrator, installs to /opt)")
    else
        SCOPE=user
    fi
fi
[ -z "$SCOPE" ] && exit 1

if [ "$SCOPE" = system ]; then
    [ -z "$PREFIX" ] && PREFIX=/opt/cryptocrack
    BINLINK=/usr/local/bin/cryptocrack
    APPDIR=/usr/share/applications
    ICONDIR=/usr/share/icons/hicolor/256x256/apps
else
    [ -z "$PREFIX" ] && PREFIX="$HOME/.local/share/cryptocrack"
    BINLINK="$HOME/.local/bin/cryptocrack"
    APPDIR="$HOME/.local/share/applications"
    ICONDIR="$HOME/.local/share/icons/hicolor/256x256/apps"
fi
PREFIX=$(absdir "$(askdir "Program folder:" "$PREFIX")")
[ -z "$DATADIR" ] && DATADIR="$HOME/CryptoCrack"
DATADIR=$(absdir "$(askdir "Data folder (sample ciphers and saved sessions):" "$DATADIR")")
BINDIR=$(dirname "$BINLINK")

SHORTCUT=0
if [ $DESKTOP -eq 1 ] && [ -d "$HOME/Desktop" ]; then yesno "Put a $APP icon on your desktop?" 1 && SHORTCUT=1; fi

if [ $PREBUILT -eq 0 ]; then
    NEED=""
    pkg-config --exists gtk+-3.0 2>/dev/null || NEED="$NEED gtk3-dev"
    command -v cc >/dev/null 2>&1 || command -v gcc >/dev/null 2>&1 || NEED="$NEED compiler"
    if [ -n "$NEED" ] && [ -n "$PKG" ]; then
        case "$PKG" in
            apt) CMD="apt-get update && apt-get install -y libgtk-3-dev build-essential pkg-config curl" ;;
            dnf|yum) CMD="$PKG install -y gtk3-devel gcc pkgconf-pkg-config curl" ;;
            pacman) CMD="pacman -S --needed --noconfirm gtk3 base-devel pkgconf curl" ;;
            zypper) CMD="zypper install -y gtk3-devel gcc pkg-config curl" ;;
        esac
        if yesno "Building CryptoCrack needs GTK 3 development files and a C compiler ($NEED).\n\nInstall them now with $PKG?" 0; then
            as_root "$CMD" || info "Installing the build tools failed. You can install them later:\n\n$CMD"
        fi
    fi
    if ! command -v cargo >/dev/null 2>&1 && [ -x "$HOME/.cargo/bin/cargo" ]; then PATH="$HOME/.cargo/bin:$PATH"; fi
    if ! command -v cargo >/dev/null 2>&1; then
        yesno "Building for $ARCH needs the Rust compiler, which is not installed.\n\nDownload and install it now from rustup.rs (into ~/.cargo, no administrator needed)?" 0 || fail "Rust is needed to build for $ARCH. Install it from https://rustup.rs and run this installer again."
        command -v curl >/dev/null 2>&1 || fail "curl is needed to download Rust."
        curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal || fail "Rust installation failed."
        PATH="$HOME/.cargo/bin:$PATH"
    fi
fi

WORK=$(mktemp -d 2>/dev/null || echo /tmp/cryptocrack-install.$$)
mkdir -p "$WORK"
trap 'rm -rf "$WORK"; [ -n "$CLEAN_PAYLOAD" ] && rm -rf "$CC_PAYLOAD_DIR"' EXIT
LOG="$WORK/install.log"

(
    echo 5; echo "# Preparing files..."
    if [ $PREBUILT -eq 1 ]; then
        ln -s "$CC_PAYLOAD_DIR/runtime" "$WORK/app"
    else
        echo 15; echo "# Building from source (this takes a few minutes)..."
        mkdir -p "$WORK/src" "$WORK/app/bin" && tar xzf "$CC_PAYLOAD_DIR/source.tar.gz" -C "$WORK/src" >>"$LOG" 2>&1
        ( cd "$WORK/src/cryptocrack/rust" && cargo build --release --features desktop --bins ) >>"$LOG" 2>&1 || { echo "BUILD" > "$WORK/failed"; exit 0; }
        cp "$WORK/src/cryptocrack/rust/target/release/cryptocrack-desktop" "$WORK/src/cryptocrack/rust/target/release/cryptocrack-linux" "$WORK/app/bin/"
        printf '#!/bin/sh\ncc_root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)\nexec "$cc_root/bin/cryptocrack-desktop" "$@"\n' > "$WORK/app/run.sh"
        chmod 755 "$WORK/app/run.sh"
    fi
    echo 70; echo "# Creating launcher and menu entry..."
    ESC_RUN=$(printf '%s' "$PREFIX/run.sh" | sed 's/\\/\\\\/g; s/"/\\"/g; s/`/\\`/g; s/\$/\\$/g; s/%/%%/g')
    cat > "$WORK/cryptocrack.desktop" <<D
[Desktop Entry]
Type=Application
Name=$APP
GenericName=Cipher solver
Comment=Classical cipher solver and analysis tools (CryptoCrack port)
Exec="$ESC_RUN"
Icon=$PREFIX/cryptocrack.png
Terminal=false
Categories=Utility;Education;Science;
StartupNotify=true
D
    printf '#!/bin/sh\nexec %s "$@"\n' "$(sq "$PREFIX/run.sh")" > "$WORK/cryptocrack-command"
    echo 85; echo "# Copying files..."
    echo 100
) | progress "Installing $APP..."
[ -f "$WORK/failed" ] && fail "Install failed at step: $(cat "$WORK/failed")\n\nLog: $(tail -n 15 "$LOG")"

SETUPCOPY=""
[ -f "$SETUPBIN" ] && SETUPCOPY="install -m 755 $(sq "$SETUPBIN") $(sq "$PREFIX/cryptocrack-setup")"
STEPS="set -e
mkdir -p $(sq "$PREFIX") $(sq "$BINDIR") $(sq "$APPDIR") $(sq "$ICONDIR")
rm -rf $(sq "$PREFIX/bin") $(sq "$PREFIX/lib") $(sq "$PREFIX/share")
cp -R $(sq "$WORK/app")/. $(sq "$PREFIX")/
install -m 644 $(sq "$CC_PAYLOAD_DIR/cryptocrack.png") $(sq "$PREFIX/cryptocrack.png")
install -m 644 $(sq "$CC_PAYLOAD_DIR/README.md") $(sq "$PREFIX/README.md")
install -m 755 $(sq "$CC_PAYLOAD_DIR/install.sh") $(sq "$PREFIX/install.sh")
$SETUPCOPY
install -m 755 $(sq "$WORK/cryptocrack-command") $(sq "$BINLINK")
ln -sf $(sq "$PREFIX/bin/cryptocrack-linux") $(sq "$BINDIR/cryptocrack-cli")
install -m 644 $(sq "$WORK/cryptocrack.desktop") $(sq "$APPDIR/cryptocrack.desktop")
install -m 644 $(sq "$CC_PAYLOAD_DIR/cryptocrack.png") $(sq "$ICONDIR/cryptocrack.png")"
if [ "$SCOPE" = system ]; then
    [ $LEGACY_DEB -eq 1 ] && STEPS="dpkg -r cryptocrack >/dev/null 2>&1 || true
$STEPS"
    as_root "$STEPS" || fail "Copying files needs administrator rights and was not allowed."
else
    [ $LEGACY_USER -eq 1 ] && rm -rf "$HOME/.local/share/cryptocrack/releases"
    sh -c "$STEPS" || fail "Copying files to $PREFIX failed."
fi

mkdir -p "$DATADIR/Ciphers" "$DATADIR/Sessions"
( cd "$CC_PAYLOAD_DIR/data" && find . -type f | while read f; do [ -e "$DATADIR/$f" ] || { mkdir -p "$DATADIR/$(dirname "$f")"; cp "$f" "$DATADIR/$f"; }; done )
CFG="${XDG_CONFIG_HOME:-$HOME/.config}/cryptocrack"
mkdir -p "$CFG"
printf '%s\n' "$DATADIR" > "$CFG/data_dir"
{ [ -f "$MANIFEST" ] && awk -F"$TAB" -v p="$PREFIX" '$2 != p' "$MANIFEST"; printf '%s\t%s\t%s\t%s\t%s\n' "$SCOPE" "$PREFIX" "$BINLINK" "$APPDIR" "$ICONDIR"; } > "$MANIFEST.new" 2>/dev/null; mv "$MANIFEST.new" "$MANIFEST"
if [ $SHORTCUT -eq 1 ]; then
    cp "$WORK/cryptocrack.desktop" "$HOME/Desktop/cryptocrack.desktop" && chmod +x "$HOME/Desktop/cryptocrack.desktop"
    command -v gio >/dev/null 2>&1 && gio set "$HOME/Desktop/cryptocrack.desktop" metadata::trusted true 2>/dev/null
fi
command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$APPDIR" >/dev/null 2>&1

PATHNOTE=""
case ":$PATH:" in
    *":$BINDIR:"*) ;;
    *)
        if [ "$SCOPE" = user ]; then
            grep -qs 'CryptoCrack PATH' "$HOME/.profile" || printf '\n# CryptoCrack PATH\n[ -d "%s" ] && PATH="%s:$PATH"\n' "$BINDIR" "$BINDIR" >> "$HOME/.profile"
            PATHNOTE="\n\n$BINDIR was added to your PATH in ~/.profile (active after your next login)."
        else
            PATHNOTE="\n\nNote: $BINDIR is not on your PATH; run $PREFIX/run.sh directly."
        fi ;;
esac

info "$APP is installed.\n\n  Program:  $PREFIX\n  Commands: cryptocrack (window), cryptocrack-cli (engine)\n  Data:     $DATADIR\n  Menu:     $APP (Utilities)\n\nSample ciphers are in $DATADIR/Ciphers.\nTo remove it later run:  sh $PREFIX/install.sh --uninstall$PATHNOTE"

if [ $DESKTOP -eq 1 ] && [ $UNATTENDED -eq 0 ]; then
    yesno "Start $APP now?" 1 && { nohup "$PREFIX/run.sh" >/dev/null 2>&1 & }
fi
exit 0
