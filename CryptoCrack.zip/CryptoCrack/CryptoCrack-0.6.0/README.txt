CryptoCrack 0.6.0

Double-click "CryptoCrack Setup" to start the install wizard.

If double-clicking opens a text editor or does nothing, right-click it,
choose Properties > Permissions and tick "Allow executing file as program",
or open a terminal in this folder and run:   ./"CryptoCrack Setup"

Other processors (ARM, Raspberry Pi) or no desktop: run   sh install.sh
