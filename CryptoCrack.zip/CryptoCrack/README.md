# CryptoCrack 0.6.0

Classical cipher solver for Linux (Rust port of CryptoCrack 4.0).

## Install

Download `CryptoCrack-0.6.0-Linux.zip`, extract it, and double-click **CryptoCrack Setup** to start the install wizard.

If double-clicking opens a text editor or does nothing, right-click it,
choose Properties > Permissions and tick "Allow executing file as program",
or open a terminal in the folder and run:

    ./"CryptoCrack Setup"

Other processors (ARM, Raspberry Pi) or no desktop:

    sh install.sh

To remove CryptoCrack, run the setup again and choose "Uninstall existing".
